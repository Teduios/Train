//
//  Factory.h
//  BaseProject
//
//  Created by apple-jd32 on 15/11/24.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"

@interface Factory : NSObject

/**向某个控制器上添加返回按钮*/
+(void)addBackItemToVC:(UIViewController *)vc;
@end

//
//  QueryTripsModel.m
//  BaseProject
//
//  Created by apple-jd32 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QueryTripsModel.h"

@implementation QueryTripsModel


+ (NSDictionary *)objectClassInArray{
    return @{@"result" : [QueryTripsResultModel class]};
}
@end
@implementation QueryTripsResultModel

@end


@implementation QueryTripsQueryleftnewdtoModel

@end



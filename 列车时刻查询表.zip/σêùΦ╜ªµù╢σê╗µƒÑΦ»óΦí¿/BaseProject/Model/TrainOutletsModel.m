//
//  TrainOutletsModel.m
//  BaseProject
//
//  Created by apple-jd32 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TrainOutletsModel.h"

@implementation TrainOutletsModel


+ (NSDictionary *)objectClassInArray{
    return @{@"result" : [TrainOutletsResultModel class]};
}
@end
@implementation TrainOutletsResultModel

@end



//
//  TrainOutletsResultCell.h
//  BaseProject
//
//  Created by apple-jd32 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TrainOutletsResultCell : UITableViewCell

@property (nonatomic,strong) UILabel *xuHao;
@property (nonatomic,strong) UILabel *daiShouDian;
@property (nonatomic,strong) UILabel *diZhi;


@end

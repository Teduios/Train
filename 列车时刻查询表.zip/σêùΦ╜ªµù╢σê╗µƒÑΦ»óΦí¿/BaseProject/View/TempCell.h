//
//  TempCell.h
//  BaseProject
//
//  Created by apple-jd32 on 15/11/28.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TempCell : UITableViewCell

@property (nonatomic,strong) UILabel *date;
@property (nonatomic,strong) UILabel *week;
@property (nonatomic,strong) UILabel *weather;
@property (nonatomic,strong) UILabel *temperature;

@end

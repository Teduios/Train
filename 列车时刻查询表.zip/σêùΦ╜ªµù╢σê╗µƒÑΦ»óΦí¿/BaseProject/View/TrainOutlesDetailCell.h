//
//  TrainOutlesDetailCell.h
//  BaseProject
//
//  Created by apple-jd32 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TrainOutlesDetailCell : UITableViewCell


@property (nonatomic,strong)UILabel *address;
@property (nonatomic,strong)UILabel *phoneON;
@property (nonatomic,strong)UILabel *shangWu;
@property (nonatomic,strong)UILabel *yingYeShiJian;
@property (nonatomic,strong)UILabel *xiaWu;



@end

//
//  TrainQueryHeadCell.h
//  BaseProject
//
//  Created by apple-jd32 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TrainQueryHeadCell : UITableViewCell

@property (nonatomic,strong)UILabel *start;
@property (nonatomic,strong)UILabel *name;
@property (nonatomic,strong)UILabel *end;
@property (nonatomic,strong)UILabel *startTime;
@property (nonatomic,strong)UILabel *mileage;
@property (nonatomic,strong)UILabel *endTime;


@end

//
//  QueryTripsCell.h
//  BaseProject
//
//  Created by apple-jd32 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QueryTripsCell : UITableViewCell



@property(nonatomic,strong) UILabel *runDistanceLb;
@property(nonatomic,strong) UILabel *startStationLb;
@property(nonatomic,strong) UILabel *endStationLb;
@property(nonatomic,strong) UILabel *endStationTypeLb;
@property(nonatomic,strong) UILabel *startTimeLb;
@property(nonatomic,strong) UILabel *runTimeLb;
@property(nonatomic,strong) UILabel *endTimeLb;
//@property(nonatomic,strong) UILabel *trainTypeLb;
@property(nonatomic,strong) UILabel *startStationTypeLb;
@property(nonatomic,strong) UILabel *trainNOLb;


//用来显示席别
@property(nonatomic,strong) UILabel *xiBie0;
@property(nonatomic,strong) UILabel *xiBie1;
@property(nonatomic,strong) UILabel *xiBie2;
@property(nonatomic,strong) UILabel *xiBie3;
@property(nonatomic,strong) UILabel *xiBie4;
@property(nonatomic,strong) UILabel *xiBie5;
@property(nonatomic,strong) UILabel *xiBie6;





@end

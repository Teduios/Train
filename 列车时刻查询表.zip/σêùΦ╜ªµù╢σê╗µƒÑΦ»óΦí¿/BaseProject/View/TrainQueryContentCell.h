//
//  TrainQueryContentCell.h
//  BaseProject
//
//  Created by apple-jd32 on 15/11/24.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TrainQueryContentCell : UITableViewCell

@property (nonatomic,strong)UILabel *trainId;
@property (nonatomic,strong)UILabel *stationName;
@property (nonatomic,strong)UILabel *arrivedTime;
@property (nonatomic,strong)UILabel *leaveTime;
@property (nonatomic,strong)UILabel *stay;


@end

//
//  TrainOutlesResultViewController.h
//  BaseProject
//
//  Created by apple-jd32 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TrainOutletsViewModel.h"
@interface TrainOutlesResultViewController : UIViewController

@property (nonatomic,strong)TrainOutletsViewModel *trainOutletsVM;

@end

//
//  TemperatureViewContronller.h
//  BaseProject
//
//  Created by apple-jd32 on 15/11/26.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TemperatureViewModel.h"
@interface TemperatureViewContronller : UIViewController

@property (nonatomic,strong) NSString *cityName;

@end

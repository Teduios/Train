//
//  TrainOutlesDetailViewController.h
//  BaseProject
//
//  Created by apple-jd32 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TrainOutlesDetailViewController : UIViewController

@property (nonatomic,strong) NSString *agencyName;
@property (nonatomic,strong) NSString *address;
@property (nonatomic,strong) NSString *phoneNO;
@property (nonatomic,strong) NSString *startAM;
@property (nonatomic,strong) NSString *stopAM;
@property (nonatomic,strong) NSString *startPM;
@property (nonatomic,strong) NSString *stopPM;


@end
